<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d9d3f4edf2b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\DataType; class Time extends DataType { }
