<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e4de4a5f042             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\DataType; class DataType { }
