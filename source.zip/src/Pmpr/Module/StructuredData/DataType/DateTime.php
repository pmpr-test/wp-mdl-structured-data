<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b4ba3b83             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\DataType; class DateTime extends DataType { }
