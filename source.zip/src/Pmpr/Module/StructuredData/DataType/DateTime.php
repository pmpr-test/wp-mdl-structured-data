<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d01d3b54cf2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\DataType; class DateTime extends DataType { }
