<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d02db44ef0d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\DataType; class Identifier extends DataType { protected $id; protected $type; protected $target; protected $permalink; public function mwikyscisascoeea() : ?string { return $this->id; } public function ggiaseqygioygumq(?string $aokagokqyuysuksm) : self { $this->id = $aokagokqyuysuksm; return $this; } public function gueasuouwqysmomu() : ?string { return $this->type; } public function aseocggwwegcmqes(?string $sqeykgyoooqysmca) : self { $this->type = $sqeykgyoooqysmca; return $this; } public function squsacgomqgkakaw() { return $this->target; } public function oockkiieqcwiocga($ccamueccusigaaio) : self { $this->target = $ccamueccusigaaio; return $this; } public function ycqquoiyyuesegsy() : ?string { return $this->permalink; } public function qmueseocuuekommo(?string $migiiksoiymissge) : self { $this->permalink = $migiiksoiymissge; return $this; } }
