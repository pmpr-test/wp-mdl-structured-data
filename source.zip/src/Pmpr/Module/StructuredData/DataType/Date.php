<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d02130bfca9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\DataType; class Date extends DataType { }
