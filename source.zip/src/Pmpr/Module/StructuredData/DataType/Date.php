<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67053261c02e5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\DataType; class Date extends DataType { }
