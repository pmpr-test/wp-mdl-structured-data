<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d01b9cd35dc             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Plugin; use Pmpr\Module\StructuredData\Container; class Woocommerce extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse('woocommerce_structured_data_product', '__return_empty_array'); } }
