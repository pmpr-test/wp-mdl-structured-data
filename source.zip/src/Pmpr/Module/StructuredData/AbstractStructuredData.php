<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517909530b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { const ocmiuacywmgycowk = StructuredData::ocmiuacywmgycowk; public function wigskegsqequoeks() { if (!($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\141\x64\144\x53\143\x68\145\155\141"))) { goto oeocukauoyosicso; } $this->qcsmikeggeemccuu("\167\160\137\x66\157\157\164\145\162", [$this, $qgciuiagkkguykgs], 9999); oeocukauoyosicso: } }
