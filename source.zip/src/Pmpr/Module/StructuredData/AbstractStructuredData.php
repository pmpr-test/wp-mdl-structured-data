<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae92b4957d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { const ocmiuacywmgycowk = StructuredData::ocmiuacywmgycowk; public function wigskegsqequoeks() { if (!($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\141\x64\144\x53\143\x68\x65\155\x61"))) { goto wkwamkgkwykeqkec; } $this->qcsmikeggeemccuu("\167\160\x5f\x66\157\157\x74\145\162", [$this, $qgciuiagkkguykgs], 9999); wkwamkgkwykeqkec: } }
