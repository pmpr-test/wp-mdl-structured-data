<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d9c26a37a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { const ocmiuacywmgycowk = StructuredData::ocmiuacywmgycowk; public function wigskegsqequoeks() { if ($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\141\144\x64\x53\x63\x68\x65\x6d\x61")) { $this->qcsmikeggeemccuu("\167\160\137\146\x6f\x6f\164\x65\x72", [$this, $qgciuiagkkguykgs], 9999); } } }
