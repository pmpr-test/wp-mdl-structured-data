<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7c260db7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { const ocmiuacywmgycowk = StructuredData::ocmiuacywmgycowk; public function wigskegsqequoeks() { if (!($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\x61\x64\144\x53\143\150\x65\155\x61"))) { goto wkwamkgkwykeqkec; } $this->qcsmikeggeemccuu("\167\x70\137\x66\x6f\157\x74\x65\x72", [$this, $qgciuiagkkguykgs], 9999); wkwamkgkwykeqkec: } }
