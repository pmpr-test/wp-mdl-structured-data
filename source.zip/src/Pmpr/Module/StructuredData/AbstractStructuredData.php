<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67053261c02e5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { const ocmiuacywmgycowk = StructuredData::ocmiuacywmgycowk; public function wigskegsqequoeks() { if ($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\x61\144\144\123\143\150\x65\x6d\141")) { $this->qcsmikeggeemccuu("\167\x70\137\x66\x6f\157\164\x65\x72", [$this, $qgciuiagkkguykgs], 9999); } } }
