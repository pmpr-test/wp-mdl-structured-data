<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ecad49867             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; abstract class AbstractStructuredData extends Container { const ocmiuacywmgycowk = StructuredData::ocmiuacywmgycowk; public function wigskegsqequoeks() { if (!($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\x61\x64\144\123\143\x68\145\155\141"))) { goto wkwamkgkwykeqkec; } $this->qcsmikeggeemccuu("\167\x70\137\x66\x6f\157\x74\145\162", [$this, $qgciuiagkkguykgs], 9999); wkwamkgkwykeqkec: } }
