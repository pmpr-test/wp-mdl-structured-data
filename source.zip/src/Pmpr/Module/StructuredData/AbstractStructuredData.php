<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d9d4bba9dd7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData; use Pmpr\Module\StructuredData\Traits\SchemaPopulatorTrait; abstract class AbstractStructuredData extends Container { use SchemaPopulatorTrait; const ocmiuacywmgycowk = StructuredData::ocmiuacywmgycowk; public function wigskegsqequoeks() { if ($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, 'addSchema')) { $this->qcsmikeggeemccuu('wp_footer', [$this, $qgciuiagkkguykgs], 9999); } } }
