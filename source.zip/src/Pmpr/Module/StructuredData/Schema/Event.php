<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc703cdceec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema; class Event extends Thing { }
