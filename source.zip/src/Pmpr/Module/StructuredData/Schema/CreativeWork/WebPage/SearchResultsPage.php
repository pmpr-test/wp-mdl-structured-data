<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d01b9cd35dc             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPage; class SearchResultsPage extends WebPage { protected ?string $query = null; public function ccwowuakmqoemoem(?string $gqgemcmoicmgaqie) : self { $this->query = $gqgemcmoicmgaqie; return $this; } public function owicscwgeuqcqaig() : ?string { return $this->query; } }
