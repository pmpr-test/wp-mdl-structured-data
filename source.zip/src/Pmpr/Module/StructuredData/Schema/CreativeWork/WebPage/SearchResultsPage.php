<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67cecae69d4c6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPage; class SearchResultsPage extends WebPage { protected ?string $query = null; public function ccwowuakmqoemoem(?string $gqgemcmoicmgaqie) : self { $this->query = $gqgemcmoicmgaqie; return $this; } public function owicscwgeuqcqaig() : ?string { return $this->query; } }
