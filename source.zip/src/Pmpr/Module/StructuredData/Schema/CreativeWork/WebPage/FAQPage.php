<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b4ba3b83             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPage; use Pmpr\Module\StructuredData\Schema\CreativeWork\Comment\Answer; use Pmpr\Module\StructuredData\Schema\CreativeWork\Comment\Question; class FAQPage extends WebPage { public function __construct(?array $oammesyieqmwuwyi = []) { if ($oammesyieqmwuwyi) { foreach ($oammesyieqmwuwyi as $momcykaoccoymeig => $igqsaukqcqscimok) { $this->ikueqmmawsgmgyiu((new Question())->usuqmwksoeaayaig($igqsaukqcqscimok->question)->iaqckqwoiseyqaku($this->cyamgsaeyiqasmcc()->ggiaseqygioygumq($momcykaoccoymeig))->ismaoyycqacwquag((new Answer())->kguaimkyumsuesem($igqsaukqcqscimok->answer)->iaqckqwoiseyqaku($this->cyamgsaeyiqasmcc()->ggiaseqygioygumq($momcykaoccoymeig)))); } $this->usuqmwksoeaayaig(__("\106\x41\121", PR__MDL__STRUCTURED_DATA)); } parent::__construct(false); } }
