<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             682fc6d774262             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\MediaObject; use Pmpr\Module\StructuredData\Schema\CreativeWork\CreativeWork; use Pmpr\Module\StructuredData\Schema\Intangible\Quantity\Distance; use Pmpr\Module\StructuredData\Schema\Intangible\StructuredValue\QuantitativeValue; class MediaObject extends CreativeWork { protected $width; protected $height; public function esyyaomkkeccysos($qeswwaqqsyymqawg) { $this->width = $qeswwaqqsyymqawg; return $this; } public function qoqouugaaimaiqmi() { return $this->width; } public function seiwcgsykwcukmsc($cswemwoyesycwkuq) { $this->height = $cswemwoyesycwkuq; return $this; } public function miskeyiwqsgcqwwo() { return $this->height; } }
