<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517909530b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPHeader extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto ugqaaewwmkocwwgy; } $this->ckqasoiiqqiuueki("\43\163\151\164\145\137\150\x65\x61\144\145\x72"); ugqaaewwmkocwwgy: parent::__construct($goiqeyeaqmicqiky); } }
