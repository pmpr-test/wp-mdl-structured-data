<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7c260db7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPSidebar extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto qicwaskssogcokgm; } $this->ckqasoiiqqiuueki("\x23\163\x69\x74\x65\x5f\x73\x69\144\145\142\x61\162"); qicwaskssogcokgm: parent::__construct($goiqeyeaqmicqiky); } }
