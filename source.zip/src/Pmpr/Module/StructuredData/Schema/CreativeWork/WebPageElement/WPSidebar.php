<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517909530b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPSidebar extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto omqiayeucoioqoao; } $this->ckqasoiiqqiuueki("\x23\163\151\164\145\x5f\x73\x69\144\x65\x62\141\x72"); omqiayeucoioqoao: parent::__construct($goiqeyeaqmicqiky); } }
