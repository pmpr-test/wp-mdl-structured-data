<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae92b4957d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPSidebar extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto qicwaskssogcokgm; } $this->ckqasoiiqqiuueki("\x23\x73\151\164\145\137\163\151\x64\145\142\141\x72"); qicwaskssogcokgm: parent::__construct($goiqeyeaqmicqiky); } }
