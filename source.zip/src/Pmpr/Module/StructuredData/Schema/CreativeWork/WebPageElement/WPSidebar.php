<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d9814dc129             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPSidebar extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if ($goiqeyeaqmicqiky) { $this->ckqasoiiqqiuueki("\x23\163\151\164\145\137\163\x69\144\x65\142\x61\x72"); } parent::__construct($goiqeyeaqmicqiky); } }
