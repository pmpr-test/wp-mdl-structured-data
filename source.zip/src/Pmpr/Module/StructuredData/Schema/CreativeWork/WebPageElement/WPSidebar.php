<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b4ba3b83             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPSidebar extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if ($goiqeyeaqmicqiky) { $this->ckqasoiiqqiuueki("\x23\x73\x69\x74\x65\137\x73\151\x64\x65\x62\x61\x72"); } parent::__construct($goiqeyeaqmicqiky); } }
