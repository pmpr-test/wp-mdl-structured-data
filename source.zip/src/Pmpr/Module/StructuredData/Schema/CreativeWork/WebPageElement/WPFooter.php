<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae92b4957d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPFooter extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto uguigkcmukuouway; } $this->ckqasoiiqqiuueki("\x23\x73\151\x74\145\x5f\x66\157\x6f\164\145\162"); uguigkcmukuouway: parent::__construct($goiqeyeaqmicqiky); } }
