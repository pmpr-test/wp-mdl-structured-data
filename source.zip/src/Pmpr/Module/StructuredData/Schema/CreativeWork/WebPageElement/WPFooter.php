<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ecad49867             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPFooter extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto uguigkcmukuouway; } $this->ckqasoiiqqiuueki("\x23\163\151\x74\145\x5f\146\157\157\x74\x65\x72"); uguigkcmukuouway: parent::__construct($goiqeyeaqmicqiky); } }
