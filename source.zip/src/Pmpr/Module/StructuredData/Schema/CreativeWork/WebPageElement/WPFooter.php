<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7c260db7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPFooter extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto uguigkcmukuouway; } $this->ckqasoiiqqiuueki("\43\x73\x69\x74\x65\x5f\x66\157\x6f\164\x65\x72"); uguigkcmukuouway: parent::__construct($goiqeyeaqmicqiky); } }
