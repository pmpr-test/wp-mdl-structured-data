<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517909530b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork\WebPageElement; class WPFooter extends WebPageElement { public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto igooksugieceoege; } $this->ckqasoiiqqiuueki("\x23\163\151\x74\145\x5f\x66\157\x6f\x74\x65\x72"); igooksugieceoege: parent::__construct($goiqeyeaqmicqiky); } }
