<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d02130bfca9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork; class EducationalOccupationalCredential extends CreativeWork { protected $credentialCategory = null; protected $competencyRequired = null; protected $educationalLevel = null; public function zswwyugkawiqgcsc($sgiwssemqqwkioak) : self { $this->credentialCategory = $sgiwssemqqwkioak; return $this; } public function oeuymkskeyqacuyw() { return $this->credentialCategory; } }
