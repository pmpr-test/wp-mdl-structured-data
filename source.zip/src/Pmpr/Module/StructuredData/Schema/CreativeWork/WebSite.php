<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517909530b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork; class WebSite extends CreativeWork { protected ?string $issn = null; public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto wkeuuycukmuqiaom; } $seumokooiykcomco = $this->caokeucsksukesyo()->ayueggmoqeeukqmq(); if ($this->suegwaomueaiseeo()) { goto ueigkucgaucgeimc; } $this->eyqkogeiqauioamw($seumokooiykcomco->ycqquoiyyuesegsy()); ueigkucgaucgeimc: if ($this->aakmagwggmkoiiyu()) { goto sggawugoykqcmsug; } $this->usuqmwksoeaayaig($seumokooiykcomco->qcgakseyaikigqco()); sggawugoykqcmsug: $this->kkqwmgsyqkqyqgge($this->weymkusmeageugsu())->akcmoueugeecmoqm($this->osswsoymmgisqmoy()); wkeuuycukmuqiaom: parent::__construct($goiqeyeaqmicqiky); } public function eqqgkcgsewmucmku(?string $gmekmommwsucqkqa) : WebSite { $this->issn = $gmekmommwsucqkqa; return $this; } public function yyacwcaacimsoyyw() : ?string { return $this->issn; } }
