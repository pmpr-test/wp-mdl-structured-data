<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc7214bc757             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork; class WebSite extends CreativeWork { protected ?string $issn = null; public function eqqgkcgsewmucmku(?string $gmekmommwsucqkqa) : WebSite { $this->issn = $gmekmommwsucqkqa; return $this; } public function yyacwcaacimsoyyw() : ?string { return $this->issn; } }
