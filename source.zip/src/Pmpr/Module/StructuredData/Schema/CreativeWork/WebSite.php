<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae92b4957d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\CreativeWork; class WebSite extends CreativeWork { protected ?string $issn = null; public function __construct($goiqeyeaqmicqiky = true) { if (!$goiqeyeaqmicqiky) { goto iqcogmsguwoikame; } $seumokooiykcomco = $this->caokeucsksukesyo()->ayueggmoqeeukqmq(); if ($this->suegwaomueaiseeo()) { goto kiwqkcaekqqyuegq; } $this->eyqkogeiqauioamw($seumokooiykcomco->ycqquoiyyuesegsy()); kiwqkcaekqqyuegq: if ($this->aakmagwggmkoiiyu()) { goto quwcqmyokicssyew; } $this->usuqmwksoeaayaig($seumokooiykcomco->qcgakseyaikigqco()); quwcqmyokicssyew: $this->kkqwmgsyqkqyqgge($this->weymkusmeageugsu())->akcmoueugeecmoqm($this->osswsoymmgisqmoy()); iqcogmsguwoikame: parent::__construct($goiqeyeaqmicqiky); } public function eqqgkcgsewmucmku(?string $gmekmommwsucqkqa) : WebSite { $this->issn = $gmekmommwsucqkqa; return $this; } public function yyacwcaacimsoyyw() : ?string { return $this->issn; } }
