<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d01b9cd35dc             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Place; use Pmpr\Module\StructuredData\Schema\Thing; class Place extends Thing { public function __construct() { $this->isGlobal = true; } }
