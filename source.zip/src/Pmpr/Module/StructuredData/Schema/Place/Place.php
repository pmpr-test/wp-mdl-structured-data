<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517909530b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Place; use Pmpr\Module\StructuredData\Schema\Thing; class Place extends Thing { public function __construct($goiqeyeaqmicqiky = true) { $this->isGlobal = true; parent::__construct($goiqeyeaqmicqiky); } }
