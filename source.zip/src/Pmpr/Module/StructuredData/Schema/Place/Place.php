<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67cecae69d4c6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Place; use Pmpr\Module\StructuredData\Schema\Thing; class Place extends Thing { public function __construct() { $this->isGlobal = true; } }
