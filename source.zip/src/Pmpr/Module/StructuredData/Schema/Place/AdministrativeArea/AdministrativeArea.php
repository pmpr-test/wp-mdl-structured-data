<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67e166667eee4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Place\AdministrativeArea; use Pmpr\Module\StructuredData\Schema\Place\Place; class AdministrativeArea extends Place { }
