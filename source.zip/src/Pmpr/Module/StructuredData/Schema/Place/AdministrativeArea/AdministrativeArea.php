<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b4ba3b83             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Place\AdministrativeArea; use Pmpr\Module\StructuredData\Schema\Place\Place; class AdministrativeArea extends Place { }
