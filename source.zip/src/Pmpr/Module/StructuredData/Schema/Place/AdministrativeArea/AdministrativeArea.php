<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705db64b53b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Place\AdministrativeArea; use Pmpr\Module\StructuredData\Schema\Place\Place; class AdministrativeArea extends Place { }
