<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67c839d2684ee             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema; class MedicalEntity extends Thing { }
