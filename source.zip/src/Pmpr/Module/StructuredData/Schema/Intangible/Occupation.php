<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc7214bc757             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible; class Occupation extends Intangible { }
