<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae92b4957d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible\Enumeration; use Pmpr\Module\StructuredData\Schema\Intangible\Intangible; class Enumeration extends Intangible { protected ?Enumeration $supersededBy = null; }
