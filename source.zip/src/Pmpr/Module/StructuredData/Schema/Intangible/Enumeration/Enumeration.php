<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d9c26a37a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible\Enumeration; use Pmpr\Module\StructuredData\Schema\Intangible\Intangible; class Enumeration extends Intangible { protected ?Enumeration $supersededBy = null; }
