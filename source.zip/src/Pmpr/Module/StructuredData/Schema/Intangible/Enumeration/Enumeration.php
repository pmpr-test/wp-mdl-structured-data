<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d9814dc129             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible\Enumeration; use Pmpr\Module\StructuredData\Schema\Intangible\Intangible; class Enumeration extends Intangible { protected ?Enumeration $supersededBy = null; }
