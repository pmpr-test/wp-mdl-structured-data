<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc703cdceec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible\Enumeration; use Pmpr\Module\StructuredData\Schema\Intangible\Intangible; class Enumeration extends Intangible { const PREFIX = 'https://schema.org/'; const emwoykayieekagwm = self::PREFIX . 'MerchantReturn'; const kgwgmysmowqukceq = self::emwoykayieekagwm . 'Unspecified'; const iigkscsmesyyemcm = self::emwoykayieekagwm . 'NotPermitted'; const seqqiewokegmsqck = self::emwoykayieekagwm . 'UnlimitedWindow'; const aueyywycywkgagiw = self::emwoykayieekagwm . 'FiniteReturnWindow'; const gmywcoewyoegywoi = self::PREFIX . 'InStock'; const ocuoayqeisgekokg = self::PREFIX . 'BackOrder'; const mokkygswukceeyms = self::PREFIX . 'OutOfStock'; protected ?Enumeration $supersededBy = null; }
