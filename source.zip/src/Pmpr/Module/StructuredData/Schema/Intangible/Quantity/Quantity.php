<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67053533b0d9b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible\Quantity; use Pmpr\Module\StructuredData\Schema\Intangible\Intangible; class Quantity extends Intangible { }
