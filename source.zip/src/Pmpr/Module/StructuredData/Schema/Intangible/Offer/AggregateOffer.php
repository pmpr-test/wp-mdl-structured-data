<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d9d4bba9dd7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible\Offer; class AggregateOffer extends Offer { protected ?string $highPrice = null; protected ?string $lowPrice = null; protected ?string $offerCount = null; public function kquoygeayegmaagg(?string $sakwyeguyoycasku) : self { $this->lowPrice = $sakwyeguyoycasku; return $this; } public function oamyaumacggaykuy(?string $yeekieykeouwcqcw) : self { $this->highPrice = $yeekieykeouwcqcw; return $this; } public function yssaceyaeekoqkci(?string $myayeaewowsgeiym) : self { $this->offerCount = $myayeaewowsgeiym; return $this; } }
