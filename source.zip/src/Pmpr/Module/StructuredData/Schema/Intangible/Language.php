<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b4ba3b83             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible; class Language extends Intangible { public function __construct($goiqeyeaqmicqiky = true) { $this->isGlobal = true; parent::__construct($goiqeyeaqmicqiky); } }
