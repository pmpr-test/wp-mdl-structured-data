<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67ceca2f1bc33             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible\ItemList\HowToItem; use Pmpr\Module\StructuredData\Schema\Intangible\ItemList\ItemList; use Pmpr\Module\StructuredData\Schema\Intangible\StructuredValue\MonetaryAmount; class HowToItem extends ItemList { protected $estimatedCost; protected ?int $position = 0; public function yqyeyqikcyswcaig() : ?int { return $this->position; } public function weakiuagguweamee(?int $kuuiuigeacouwmaa) : self { $this->position = $kuuiuigeacouwmaa; return $this; } public function scecwgoqwqwaamgq() { return $this->estimatedCost; } public function ecqgemyswuaswooa($cscgeyumqcskuukg) : self { $this->estimatedCost = $cscgeyumqcskuukg; return $this; } }
