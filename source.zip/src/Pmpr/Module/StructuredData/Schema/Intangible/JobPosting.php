<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d9c26a37a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible; class JobPosting extends Intangible { }
