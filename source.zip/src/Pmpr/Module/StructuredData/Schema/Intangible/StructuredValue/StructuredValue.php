<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67ceddae29f34             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible\StructuredValue; use Pmpr\Module\StructuredData\Schema\Intangible\Intangible; class StructuredValue extends Intangible { }
