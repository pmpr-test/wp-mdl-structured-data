<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800fbcc87ea2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible\StructuredValue; class MonetaryAmount extends StructuredValue { protected ?string $currency = null; protected ?string $value = null; public function useawgqusasoukqm() : ?string { return $this->currency; } public function yakomucykaieeiqq(?string $wwigiesyquoeawog) : self { $this->currency = $wwigiesyquoeawog; return $this; } public function qooeaookuemoqecm() : ?string { return $this->value; } public function iygyugseyaqwywyg(?string $eqgoocgaqwqcimie) : self { $this->value = $eqgoocgaqwqcimie; return $this; } }
