<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d01b9cd35dc             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible\StructuredValue; class OfferShippingDetails extends StructuredValue { protected ?MonetaryAmount $shippingRate = null; protected ?ShippingDeliveryTime $deliveryTime = null; public function ywekuyamiqyeiusg(?ShippingDeliveryTime $wkwskcqysckmgaku) : self { $this->deliveryTime = $wkwskcqysckmgaku; return $this; } public function ymwyioiigeqgywcw(?MonetaryAmount $gyqsakmgwigysioq) : self { $this->shippingRate = $gyqsakmgwigysioq; return $this; } }
