<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d01b9cd35dc             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Intangible\StructuredValue; class Common extends StructuredValue { protected $value = 0; protected int $maxValue = 0; protected int $minValue = 0; protected ?string $unitCode = null; protected ?string $unitText = null; public function gumwccecwiciceie() : int { return $this->maxValue; } public function aiqgwwukmuuywegc(int $wyyyoqckegkksimm) : Common { $this->maxValue = $wyyyoqckegkksimm; return $this; } public function akgameoyuaqyiciy() : int { return $this->minValue; } public function woekgcawwwikycii(int $ekugmsskqyycmksc) : Common { $this->minValue = $ekugmsskqyycmksc; return $this; } public function qooeaookuemoqecm() { return $this->value; } public function iygyugseyaqwywyg($eqgoocgaqwqcimie) { $this->value = $eqgoocgaqwqcimie; return $this; } public function ueqaqoqsecaqkgiw() : string { return $this->unitCode; } public function iiyqwmsqmckkkoks(string $uqcueqykyaigsmei) : Common { $this->unitCode = $uqcueqykyaigsmei; return $this; } public function aaqkogkggmskmcmy() : string { return $this->unitText; } public function ocaqoaoyequgqeok(string $euaqyemwswoiueks) : Common { $this->unitText = $euaqyemwswoiueks; return $this; } }
