<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc7214bc757             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Action; class SearchAction extends Action { protected $query_input = null; public function goeakuiyqeiyqayo($query_input) { $this->query_input = $query_input; return $this; } public function imqckaewuqaicoyg() { return $this->query_input; } }
