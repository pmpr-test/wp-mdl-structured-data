<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             682fc6d774262             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Action; use Pmpr\Module\StructuredData\Schema\Intangible\EntryPoint; use Pmpr\Module\StructuredData\Schema\Thing; class Action extends Thing { protected $target = null; public function oockkiieqcwiocga($ccamueccusigaaio) : Action { $this->target = $ccamueccusigaaio; return $this; } public function squsacgomqgkakaw() : EntryPoint { return $this->target; } }
