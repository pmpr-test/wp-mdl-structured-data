<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67053533b0d9b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Custom; use Pmpr\Module\StructuredData\Schema\CreativeWork\Blog; class Tag extends Blog { public function __construct($goiqeyeaqmicqiky = true) { if ($goiqeyeaqmicqiky) { $aoskwucuugeuaeus = $this->caokeucsksukesyo()->kckogqkiycqeumoa(); $ewsqcacamuomwagw = $this->uwkmaywceaaaigwo()->ogciwyoqgciosgcw(); $scwiymciagumsuiw = $aoskwucuugeuaeus->get($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->qaumqeeagueuqkcg("\x74\141\x67\x5f\151\144")); $migiiksoiymissge = $aoskwucuugeuaeus->qmgcisuuikgmqcsu($scwiymciagumsuiw); $this->mqqgwegyyqkgoqeg(null)->kwcomqeygmcaegeo(sprintf(__("\x54\141\147\40\x25\163", PR__MDL__STRUCTURED_DATA), $ewsqcacamuomwagw->ciiwwmaoykeuooma(false)))->gucwmccyimoagwcm($ewsqcacamuomwagw->sgqgswskkowaiqeq())->eyqkogeiqauioamw($migiiksoiymissge)->aseocggwwegcmqes("\x42\154\x6f\x67")->iaqckqwoiseyqaku($this->cyamgsaeyiqasmcc()->oockkiieqcwiocga($scwiymciagumsuiw)->qmueseocuuekommo($migiiksoiymissge)->aseocggwwegcmqes("\124\141\x67")); } parent::__construct($goiqeyeaqmicqiky); } }
