<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d9d3f4edf2b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Organization; use Pmpr\Module\StructuredData\Schema\Person; class EducationalOrganization extends Organization { protected ?Person $alumni = null; public function kmwsmimgmgsaocku() : ?Person { return $this->alumni; } public function egmiwmaceicoimgm(?Person $womiwkocccuimwwe) : self { $this->alumni = $womiwkocccuimwwe; return $this; } }
