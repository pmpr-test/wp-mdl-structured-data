<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d01d3b54cf2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Schema\Organization; use Pmpr\Module\StructuredData\Schema\Person; class EducationalOrganization extends Organization { protected ?Person $alumni = null; public function kmwsmimgmgsaocku() : ?Person { return $this->alumni; } public function egmiwmaceicoimgm(?Person $womiwkocccuimwwe) : self { $this->alumni = $womiwkocccuimwwe; return $this; } }
