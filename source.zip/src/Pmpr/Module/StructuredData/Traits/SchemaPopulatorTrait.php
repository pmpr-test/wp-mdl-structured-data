<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68dfe8127d0bb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Traits; use Pmpr\Module\StructuredData\SchemaPopulator; trait SchemaPopulatorTrait { public function qukwsgoewmiomios() : SchemaPopulator { return SchemaPopulator::symcgieuakksimmu(); } }
