<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67ceddae29f34             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Traits; use Pmpr\Module\StructuredData\SchemaPopulator; trait SchemaPopulatorTrait { public function qukwsgoewmiomios() : SchemaPopulator { return SchemaPopulator::symcgieuakksimmu(); } }
