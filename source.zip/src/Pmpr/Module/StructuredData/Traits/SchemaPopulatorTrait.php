<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc7214bc757             |
    |_______________________________________|
*/
 namespace Pmpr\Module\StructuredData\Traits; use Pmpr\Module\StructuredData\SchemaPopulator; trait SchemaPopulatorTrait { public function qukwsgoewmiomios() : SchemaPopulator { return SchemaPopulator::symcgieuakksimmu(); } }
