<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d9d3f4edf2b             |
    |_______________________________________|
*/
 use Pmpr\Module\StructuredData\StructuredData; StructuredData::symcgieuakksimmu();
