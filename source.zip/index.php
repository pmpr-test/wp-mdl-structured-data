<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705db64b53b             |
    |_______________________________________|
*/
 use Pmpr\Module\StructuredData\StructuredData; StructuredData::symcgieuakksimmu();
