<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d01b9cd35dc             |
    |_______________________________________|
*/
 use Pmpr\Module\StructuredData\StructuredData; StructuredData::symcgieuakksimmu();
